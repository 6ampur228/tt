# Telegram Referral System - Railway Deploy

1. Upload this folder to GitHub.
2. Add environment variables in Railway:
   BOT1_TOKEN=
   BOT2_TOKEN=
   SUPABASE_URL=
   SUPABASE_KEY=
3. Deploy.
